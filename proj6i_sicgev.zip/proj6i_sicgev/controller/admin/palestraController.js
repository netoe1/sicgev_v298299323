const { Op } = require('sequelize');
const models = require('../../database/models')
const Palestra = models.Palestra;
const Evento = models.Evento;
const Ministrante = models.Ministrante;



//função que lista todos ítens
async function lst(req, res) {
  const listar_palestras = await Palestra.findAll({});
  res.render("admin/palestra/lst" , {Logado:req.user, Palestras:listar_palestras});
}
//função que lista todos ítens de acordo com pesquisa
async function filtro(req, res) {
  const palestras = await Palestra.findAll({
    where:{
      nome: {
        [Op.iLike]: '%'+req.body.pesquisar+'%'
      }
    }
  })
  res.render("admin/palestra/lst" , {Logado:req.user, Palestras:palestras});
}
//função que abre a tela de add
async function abreadd(req, res) {
    const eventos = await Evento.findAll({});
    const ministrantes= await Ministrante.findAll({});
    
    res.render("admin/palestra/add", { Logado:req.user, Eventos:eventos,Ministrantes:ministrantes});
  
}
//função que adiciona
async function add(req, res) {
  console.log(req.body);
  const palestra = await Palestra.create({
    titulo:req.body.titulo,
    resumo:req.body.resumo,
    dataehora:req.body.dataehora,
    eventoId:req.body.eventoId,
    ministranteId:req.user.ministranteId

  }).catch(function(err) {
    console.log(err)
    
  });

  res.redirect('/admin/palestra/lst')
}
//função que abre tela de edt
async function abreedt(req, res) {
    const ministrantes = await Ministrante.findAll({});
    const eventos = await Evento.findAll({});
    const palestra = await Palestra.findByPk(req.params.id);
    res.render("admin/palestra/edt", {Logado:req.user,Palestra:palestra,Eventos:eventos,Ministrantes:ministrantes});
}
//função que edita
async function edt(req, res) {
  const palestra = await Palestra.findByPk(req.params.id);

  await palestra.update({
    titulo:req.body.titulo,
    resumo:req.body.resumo,
    dataehora:req.body.dataehora,
    eventoId:req.body.eventoId,
    ministranteId:req.user.ministranteId
  })
  res.redirect('/admin/palestra/lst')
}
//função que deleta ítens
async function del(req, res) {
  const palestra = await Palestra.findByPk(req.params.id);
  await palestra.destroy()
  res.redirect('/admin/palestra/lst')
}

module.exports = { lst, filtro, abreadd, add, abreedt, edt, del };